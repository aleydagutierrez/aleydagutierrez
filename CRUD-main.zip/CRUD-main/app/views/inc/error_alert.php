<article class="message is-danger">
	 <div class="message-header">
	    <p>¡Ocurrio un error inesperado!</p>
	 </div>
    <div class="message-body">No se pudo cargar los datos solicitados</div>
</article>