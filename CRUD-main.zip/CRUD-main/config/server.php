<?php

	const DB_SERVER="localhost";
	const DB_NAME="";
	const DB_USER="root";
	const DB_PASS='';